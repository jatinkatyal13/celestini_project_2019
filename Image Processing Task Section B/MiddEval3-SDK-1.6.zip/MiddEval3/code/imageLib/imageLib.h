// imageLib.h

// common includes

#ifndef CIMAGELIB
#define CIMAGELIB

#include "Error.h"
#include "Image.h"
#include "ImageIO.h"
#include "Convert.h"

#endif
